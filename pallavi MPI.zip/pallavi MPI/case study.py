


import numpy as np
import pandas as pd
data1= pd.read_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\data1.csv")
data2=pd.read_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\data2.csv")


#1.	Create a table from Data 1 where MPI of Urban and Rural are greater than It’s Average
print 'average of MPI urban', np.mean(data1["MPI Urban"])
print 'average of MPI rural',np.mean(data1["MPI Rural"])
new_table =data1[(data1["MPI Rural"] > np.mean(data1["MPI Rural"])) & (data1["MPI Urban"] > np.mean(data1["MPI Urban"]))]
print new_table
#new_table.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\1table.csv")  # to output in csv file



#2.	Get the Count of Rows where any of the line Items is not having the Value (from Data1 and Data2)
total=0
for i in range(len(data1.isnull().sum())):
    total= data1.isnull().sum()[i]+total
print "Number of rows: {} not having the value in any of line items in data1".format(total)
print data1.isnull().sum()    # 5 rows having NAN
total=0
for i in range(len(data2.isnull().sum())):
    total= data2.isnull().sum()[i]+total
print "Number of rows: {} not having the value in any of line items in data2".format(total)
print data2.isnull().sum()    # 1 row having NAN



#3.	Create a new column as first name to get the first name of the Country (from Data 1)
from pycountry import countries
from iso3166 import countries
first_name=[]
for i in data1.ISO:
    first_name.append(countries.get(i).apolitical_name.split()[0])
first_name=pd.DataFrame({'first name':first_name})
data1=data1.join(first_name)
print data1
#data1.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\3table.csv")  # to output in csv file


#4.	Create a Table where Intensity of Rural Deprivation is less than the average(Data1)
print "Avg Intensity of Rural Deprivation", np.mean(data1["Intensity of Deprivation Rural"])
IRD_table =data1[(data1["Intensity of Deprivation Rural"] < np.mean(data1["Intensity of Deprivation Rural"]))] 
print IRD_table
#IRD_table.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\4table.csv")  # to output in csv file


#5.	Analyze the Data from both the Datasets and Try to Get the Country level Data map to its Sub-national region data.
country_level=data2.groupby(['ISO country code','Country','World region'])["MPI National","MPI Regional","Headcount Ratio Regional","Intensity of deprivation Regional"].mean()
#country_level.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\5table.csv")  # to output in csv file


#6.	Identify the Data which is present in Data 1 but Missing in Data2
data=data1.copy(deep= True) 
unique_countries= np.array(sorted(set(data2.Country)))
a=[i for i in range(len(data.Country)) if data.Country[i] in unique_countries]
data.drop(data.index[a],inplace= True)
print 'Following countries Data missing in data2'
print data
#data.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\6table.csv")  # to output in csv file



#7.	Get the average of Intensity of deprivation Regional from Dat2 for Country-Wise and World Region Wise-Accordingly.
country_wise=data2.groupby(['Country'])['Intensity of deprivation Regional'].mean()
print 'country wise data'
print country_wise
world_wide=data2.groupby(['World region'])['Intensity of deprivation Regional'].mean()
print 'World region wise data'
print world_wide
#world_wide.to_csv("C:\\Users\\SAGEABLE\\Desktop\\case study\\7table.csv")  # to output in csv file

