# You-Tube-Spam-Collections
The aim of this project is to explore the results of applying machine learning techniques to Message spam or ham detection
